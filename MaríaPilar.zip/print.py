primero = input("Introduce un número: ")
segundo = input("Introduce otro número: ")
num1 = int(primero)
num2 = int(segundo)
suma = num1 + num2

name = input("Introduce tu nombre: ")
surname = input("Introduce tu primer apellido: ")
age = input("Introduce tu edad: ")
complete = f"{name} {surname}"
print(f"Buenos dias {complete.title()} , el resultado de su suma es: " + str(suma) )
frase1 = input(f" {complete.title()} con {age} tiene que introducir su color favorito: " )
print("Enhorabuena lorucho, has ganado un abrazo")