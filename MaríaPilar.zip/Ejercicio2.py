#Vamos a pedir que introduzcan su nombre su apellido y su edad
name = input("Introduce tu nombre:")
surname = input("Introduce tu apellido:")
age = input("Introduce tu edad:")

complete = f"{name} {surname}"
print(f"Tu nombre completo es {complete.title()} y tienes {age} años.")
