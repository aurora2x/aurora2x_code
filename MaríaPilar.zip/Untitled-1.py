# Say·hello·to·everyone.
print("Hello python people!")

#Vamos a calcular el cuadrado de 4
x = 4*4
y = 4**2
print("El cuadrado de 4 es " + str(x))
print("El cuadrado de 4 es " + str(y))

#Vamos a introducir unas comillas dentro de un texto
message = "One of the python's\"strengths\"is its divers"
print(message)

first_name="María"
last_name="Pilar"
#Full_name= first_name + " " + last_name
full_name = f"{first_name}{last_name} es mi amiga"
print(full_name)